<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<style>
div.ex1 {
    margin-bottom: 8px;
}
</style>
<?php include('public/add-category-form.php'); ?>
<?php include('public/footer.php'); ?>